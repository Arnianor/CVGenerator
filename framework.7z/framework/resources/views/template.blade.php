<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="UTF-8">
	</head>
	<body>
		@yield('content')
	</body>
</html>