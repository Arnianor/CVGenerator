@extends('template')

@section('content')
	<h1>Formulaire valid�</h1>
@stop